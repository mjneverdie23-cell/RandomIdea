# DraftCall Predictor Lab — Notebook

A standalone sandbox for the DraftCall prediction model. Every constant in the
model is a knob you can turn, and you can grade the result against real games
yourself instead of asking someone to run it for you.

**This is a mod. It does not touch the live app.** Nothing in this folder is
imported by DraftCall, and changing anything here changes nothing about the
predictor on the site.

---

## Contents

| file | what it is |
|---|---|
| `predictor-lab.html` | The whole lab. Open it in a browser — no install, no build, no internet. |
| `run.mjs` | Command-line runner. Extracts the model out of the HTML and runs it under Node. |
| `sweep.mjs` | Sweeps one setting across a range and prints the curve. |
| `presets/*.json` | Example settings files. |
| `NOTEBOOK.md` | This file. |

The model lives in exactly one place: the `<script id="lab-core">` block inside
`predictor-lab.html`. `run.mjs` and `sweep.mjs` read that same block, so the
browser and the command line can never disagree with each other.

---

## 1. Getting data

The lab reads **Oracle's Elixir match data CSVs** — the full exports, the ones
with 160-odd columns including `golddiffat10` and the `ban1`..`ban5` columns.
Get them from oracleselixir.com (Downloads). One file per season.

Trimmed exports (the ~24-column ones) will be rejected with a message telling
you which column is missing.

You do not need to pre-filter the files by league. Load whole seasons and use
the **Backtest scope** settings to choose what gets graded — history should
always be as wide as possible even when you are only grading the LCK.

---

## 2. Using it in the browser

1. Open `predictor-lab.html` (double-click, or drag it into a browser tab).
2. Drop one or more season CSVs onto the box at the top left.
3. Change whatever settings you want.
4. Press **Run backtest**.

**A/B vs defaults** is usually what you actually want. It runs your settings and
the shipped defaults over the same games and reports the difference, the number
of games where the two disagreed, and whether that difference is bigger than
noise. A single accuracy number in isolation is very easy to fool yourself with.

**Save settings** writes a JSON file containing only what you changed from the
defaults. That file can be loaded back in, passed to `run.mjs --settings`, or
kept as a record of an experiment.

A few thousand games run in about a second. Whole multi-season loads are fine.

---

## 3. Using it from the command line

Better for anything long, and the only sane way to do sweeps.

```bash
# straight backtest
node run.mjs data/2025.csv

# several seasons at once — history spans all of them
node run.mjs data/2023.csv data/2024.csv data/2025.csv

# override settings without a file
node run.mjs --set pocketPoint=2.5 --set leagues=LCK data/*.csv

# use a saved settings file
node run.mjs --settings presets/halved-game1-pocket.json data/*.csv

# A/B two settings files over identical games
node run.mjs --ab presets/halved-game1-pocket.json data/*.csv

# dump the graded rows for your own analysis
node run.mjs --json out.json data/*.csv
```

Sweeping one setting:

```bash
node sweep.mjs --key pocketPoint --from 0.5 --to 3 --step 0.25 data/*.csv
node sweep.mjs --key probScale  --from 1.5 --to 5 --step 0.5  data/*.csv
```

No `npm install` is needed. Node 18 or newer.

---

## 4. What the settings mean

Hover any label in the sidebar for the same explanation. Notes below say what
has already been measured, so you do not repeat work.

### Draft scoring

| setting | default | notes |
|---|---|---|
| `metaPoint` | 1.0 | Points per champion that clears the meta bar in its role. |
| `pocketPoint` | 1.5 | Points per off-meta pick. Sweeps flat from about 1.0 to 1.5 and falls off hard above 2.0. |
| `pocketMax` | 2 | Off-meta picks allowed before the draft reads as chaos rather than a plan. |
| `pocketManyPenalty` | −2.0 | Flat score once `pocketMax` is exceeded. Measured badly wrong on 2023–25 data at exactly 3 picks — see §9. |
| `gameOnePocketScale` | 1.0 | Multiplier on the pocket term in game 1. `0.5` is the old halving rule the app used until Sep 2026. |
| `darkHorsePoint` | 0.1 | Per pick on the dark-horse list. Has never helped in any backtest; set 0 to drop it. |
| `darkHorseList` | LeeSin,Akali,Nocturne | Champion ids, letters and digits only (`RenataGlasc`, `KaiSa`). |

### Win-rate base

| setting | default | notes |
|---|---|---|
| `winRateCap` | 5 | Ceiling on the five lanes' summed win rates. |
| `unplayedWinRate` | 1.0 | Credited when a starter picks an **off-meta** champion with no record — the "prepared surprise" rule. |
| `neutralWinRate` | 0.5 | Credited when neither player nor team has any record. |
| `minSplitSample` | 2 | Games needed in the current split before a split record is trusted. |
| `blendSplitCareer` | on | On: average split and career. Off: split alone when it qualifies. |
| `shrinkage` | 0 | Pulls thin records toward 50%: `(w + k/2) / (g + k)`. Try 4. Untested — a good first experiment. |
| `rosterSource` | history | `history` = last player seen in that role (what the live app can know from a team name). `actual` = who really started, which you also know at draft time. |

### Team-level edges

| setting | default | notes |
|---|---|---|
| `formScale` / `formCap` | 2.0 / 1.0 | Points per full 100% gap in series win rate, and the ceiling. |
| `minFormSeries` | 3 | Below this many completed series a team takes no form edge. |
| `seriesLeadPoint` / `seriesLeadCap` | 0.3 / 0.6 | Credits the series **leader**. The sign is deliberate: teams facing elimination lose more, not less. |

### Rank edge

| setting | default | notes |
|---|---|---|
| `rankSource` | elo | `off` = no cross-region term. `elo` = a rolling rating built from results before each game. |
| `rankPoint` / `rankCap` | 0.1 / 1.5 | Points per place of gap, and the ceiling. |
| `rankDeadband` | 0 | Ignore gaps smaller than this many places. |
| `eloK` / `eloStart` | 24 / 1500 | How fast the rating moves, and where teams enter. |

**Why Elo and not the app's GlobalRank table.** The live app uses a
hand-maintained ranking. That table is a *snapshot* — it is not cut at kickoff
like every other term — so backtesting an old season with it means scoring
January games with ranks that already know how the year finished. The lab
derives a rating from results before each game instead, which is slower to
react but cannot see the future. It is the honest version, and on 2023–25 it
lands at the same overall accuracy.

Elo only becomes comparable *across* regions because international events exist.
If you load one league's games only, the rank edge is measuring intra-league
strength, which the form edge already covers — expect it to add little.

### Meta pool

| setting | default | notes |
|---|---|---|
| `metaPatchCount` | 2 | Most recent patches that define "current meta". |
| `metaPickRate` | 0.05 | Share of games a champion must appear in, in its role. |
| `metaMinPicks` | 4 | Absolute floor so nothing goes meta on a tiny window. |
| `countBans` | on | Presence = picks + bans. Off, a permabanned champion reads as *off-meta* and wrongly earns a pocket bonus. |

### Probability

`probScale` converts the point margin to a probability:
`p = 1 / (1 + exp(−margin / scale))`. **It cannot change accuracy** — only how
confident the model sounds, and therefore the Brier score. The report tells you
the scale that would have been best; the default of 2.0 is consistently too
confident and the fitted value lands nearer 3.5–4.0.

### Backtest scope

`leagues`, `years`, `games` are comma-separated filters on **what gets graded**.
History always spans everything loaded. `minHistory` skips the cold-start games
at the very beginning of the earliest file, where the model knows nothing.
`excludeBo1` grades only games inside a multi-game series.

---

## 5. Reading the output

**Accuracy** is the headline, but compare it against the **blue-side base rate**
printed underneath. Blue wins about 53% of pro games, so 53% accuracy is worth
nothing. Anything in the low 60s is a real model.

**Brier** is the mean squared probability error — lower is better, 0.25 is a
coin flip. It rewards being right *and* being appropriately confident.

**Matched Brier** re-fits `probScale` to the games just graded and reports the
score the model would get with its confidence tuned. Use it when comparing two
variants, because raw Brier partly measures which variant happens to be more
confident rather than which is more right. It is fitted in-sample, so it is a
diagnostic, not a held-out score.

**Disagreements** is the important one in an A/B. Two variants that pick the
same side in 99% of games cannot be separated by the 1% left over, no matter
how different their accuracy looks. The lab prints the head-to-head record on
just those games and a two-sided p-value. Below about 30 disagreements, or a
p above 0.05, you have not learned anything — and the lab will say so.

**The trap this is all built to avoid:** with ~5,000 games, a difference of
±15 games is roughly what you get from shuffling nothing at all. Almost every
tempting idea lands inside that band. Sweep the setting; if the curve is flat,
the term does nothing and the best value in your list is luck.

---

## 6. Adding a new setting

Two steps.

**Step 1 — declare it** in `SETTINGS_SCHEMA`, in the `<script id="lab-core">`
block. Find the group it belongs in and add an entry:

```js
{ key: 'firstBloodPoint', label: 'First blood', def: 0.2, step: 0.05,
  help: 'Points for the side that historically draws first blood more often.' },
```

Fields: `key` (the settings name), `label` (sidebar text), `def` (default
value), and `help` (the tooltip). Optional `type`:

- omitted → number input (use `step` to set the increment)
- `'bool'` → checkbox
- `'text'` → free text (use `csvList(v)` to read a comma-separated list)
- `'select'` → dropdown, with `options: ['a','b']`

**Step 2 — use it.** It is now `s.firstBloodPoint` everywhere the settings
object `s` is in scope. The sidebar control, the default value, the JSON
save/load, `--set firstBloodPoint=0.3` and `sweep.mjs --key firstBloodPoint`
all start working with no further changes.

---

## 7. Adding a new scoring term

Worked example: **give a side points for having played each other recently and
won** — a head-to-head term.

### 7a. Add the setting

```js
{ key: 'h2hPoint', label: 'Head-to-head', def: 0.0, step: 0.1,
  help: 'Points per net previous win over this specific opponent, capped.' },
{ key: 'h2hCap', label: 'Head-to-head cap', def: 1.0, step: 0.25,
  help: 'Ceiling on the head-to-head term.' },
```

Default it to **0** so it is off until you deliberately turn it on. That way
the defaults stay the shipped model and every A/B remains meaningful.

### 7b. Store what it needs, in the `Model` class

Add the counter to the constructor:

```js
this.h2h = new Map();   // "teamA|teamB" -> net wins for teamA
```

and fill it in `addGame()`, which runs **only after the game has been graded**.
`addGame` is a method on `Model`, so `this` is the model. Store the tally
against a stable key — the alphabetically first team — so the two teams always
hash to the same entry whichever side they are on:

```js
const a = g.blue.team.toLowerCase(), b = g.red.team.toLowerCase();
const [lo, hi] = a < b ? [a, b] : [b, a];
const loWon = (g.blue.won ? a : b) === lo;
this.h2h.set(lo + '|' + hi, (this.h2h.get(lo + '|' + hi) ?? 0) + (loWon ? 1 : -1));
```

### 7c. Score it, in `predict()`

Cross-side terms go in `predict()`; per-side terms go in `scoreSide()`. This
one compares the two sides, so it belongs in `predict()`.

Note that `predict(model, g)` is a plain function, **not** a method — reach the
state through `model`, not `this`:

```js
if (s.h2hPoint !== 0) {
  const a = g.blue.team.toLowerCase(), b = g.red.team.toLowerCase();
  const [lo, hi] = a < b ? [a, b] : [b, a];
  const netLo = model.h2h.get(lo + '|' + hi) ?? 0;
  const netBlue = a === lo ? netLo : -netLo;
  const award = Math.min(Math.abs(netBlue) * s.h2hPoint, s.h2hCap);
  if (netBlue > 0) blue.h2h = award; else if (netBlue < 0) red.h2h = award;
}
```

### 7d. Add it to the total

In `scoreSide()`, initialise the field so both sides always have it:

```js
form: 0, seriesEdge: 0, rank: 0, h2h: 0,
```

and add it to the sum at the bottom of `predict()`:

```js
const tot = (x) => x.base + x.metaBonus + x.pocket + x.form
  + x.seriesEdge + x.rank + x.darkHorse + x.h2h;
```

### 7e. Test it honestly

```bash
node run.mjs --set h2hPoint=0.3 --ab presets/shipped-defaults.json data/*.csv
node sweep.mjs --key h2hPoint --from 0 --to 1 --step 0.1 data/*.csv
```

Then do the thing that separates a real term from a flattering one — **run the
wrong-sign control**:

```bash
node sweep.mjs --key h2hPoint --from -0.5 --to 0.5 --step 0.1 data/*.csv
```

If the negative side of the sweep helps about as much as the positive side, the
term is fitting noise and the "improvement" was a coin landing your way. A real
signal is clearly asymmetric about zero.

Running exactly the above on 2023–25 gives:

```
  h2hPoint      graded  accuracy      W-L      Brier
  -0.4            5631   55.98%   3150-2477   0.2837
  -0.2            5631   61.05%   3436-2192   0.2513
   0              5631   64.23%   3615-2013   0.2356
   0.2            5631   64.69%   3640-1987   0.2378
   0.4            5631   64.55%   3633-1995   0.2394
```

Strongly asymmetric, so it is not pure noise — and about **+25 games** at its
best, with the Brier slightly *worse*. This is the exact situation the tooling
exists for, and it is worth being clear about what it does and does not show:

- The asymmetry is not proof on its own. A wrong-signed version of any genuinely
  predictive feature will anti-predict and look terrible, so a bad negative half
  is necessary, not sufficient.
- +25 games out of 5,631 is only a little outside the noise band.
- Most of all, head-to-head is probably not *new* information. A team that keeps
  beating another is simply the better team, which the Elo rank edge and the
  form edge already price in — so this may be double-counting rather than adding.

On the live model this term was tried and **failed holdout validation**: it
looked like a small gain on the tuning data and did not survive on games held
back. That is why it is not in the app, and it is the check to run before you
believe any term of this size. Splitting your seasons is the cheap version:
tune on 2023–24, confirm on 2025.

---

## 8. The one rule: no lookahead

The model must never see the game it is predicting, or anything after it.

The lab enforces this **structurally** rather than with date arithmetic. Games
are sorted oldest-first and the loop is:

```
for each game:
    predict it              <- model contains only earlier games
    record the result
    model.addGame(game)     <- only now does it learn from this game
```

So if you add state, **update it in `addGame()` and nowhere else**. The moment
you populate a counter during `predict()`, or precompute something from the
whole file and read it while scoring, the results become fiction — and the
symptom is not a crash, it is a suspiciously good accuracy.

Two subtler cases already handled, worth copying if you add similar state:

- **Series records** are credited only when a series has fully *finished*, and
  strictly before the current game's timestamp — so a game inside a series
  never benefits from that series' outcome.
- **The series score** passed to the model is the score *before* the current
  game, computed in `buildSeries()`.

Signs you have leaked the future: accuracy above about 75%, a term that helps
enormously and equally in its wrong-sign control, or an early-season number as
good as a late-season one.

---

## 9. Things already measured

Worth knowing before you spend an evening rediscovering them. All of these were
run on 2023–25 or the 2026 season, or both.

| idea | verdict |
|---|---|
| Counting bans toward meta presence | **Helped.** Shipped. Without it, permabanned champions read as pocket picks. |
| Removing the game-1 pocket halving | Shipped on 2026 data (+3 games), but 2023–25 mildly prefers the halving (+8 to +18). Both inside noise. `gameOnePocketScale` lets you re-test. |
| `pocketPoint` above 2.0 | **Clearly worse**, monotonically. Optimum is broad and flat from about 1.0 to 1.5. |
| `pocketManyPenalty` at 3 picks | **Suspect.** On 2023–25, teams with 3 pocket picks against an all-meta draft won 52%, while the −2 penalty implies 18%. |
| Champion scaling (early/late game) | Ran backwards — late-game sides won 44.8%. Reported in the app, not scored. |
| Class affinity (player off-type picks) | Lost games in every form tried. Reported, not scored. |
| Head-to-head | Failed holdout validation on the live model. In the lab it shows about +25 games on 2023–25 with a worse Brier — see §7e for why that is not a green light. |
| Rank-edge deadband | −12 to −18 games. |
| Dark horse | Never helped in four attempts; never hurt much either. |
| Fraud rating | The single most harmful term ever tried — alone it picked winners 44% of the time. Removed. |
| `probScale` 2.0 | Too confident. Fitted optimum is nearer 3.5–4.0. Does not change accuracy. |
| `shrinkage` = 4 | **Free calibration.** −2 games (nothing), but Brier 0.2356 → 0.2297. Better probabilities at no cost in accuracy. |
| Derived Elo rank edge | **Worth +139 games** on 2023–25 (p < 0.001) — and unlike the app's ranking table it cannot see the future. Run `presets/no-rank-edge.json` to see it. |

Not yet tried, and probably the most promising: a pooled/recency-weighted
win-rate base to replace the split/career mean.

---

## 10. How faithful is this to the live app?

Close, but not identical, and you should know where it differs before quoting a
number from here as if it came from the app.

**The same:** the additive scoring structure, the win-rate ladder
(split+career blend → split → career → prepared surprise → team record → even),
the meta pool definition including ban counting, the pocket rules, the form
edge, the series-lead term, the dark-horse term, and the logistic.

**Different on purpose:**

| | live app | lab |
|---|---|---|
| Rank edge | Hand-maintained GlobalRank snapshot | Rolling Elo derived from prior results |
| Motivation | User states it per game | Not available in a results export — omitted |
| Matchup graph / notices | Rendered for the reader | Omitted; they never moved the score |
| Team and champion names | Normalised through the app's alias tables | Raw CSV strings |
| Series detection | From the match queue | Inferred: same two teams, same calendar day |

**Sanity check:** on the same three seasons (2023–25, 5,631 graded games) the
lab reports **64.2%** overall and 69.8% in the LCK. The app's own harness on the
same seasons reported 64.1% and 69.9% — with the anachronistic ranking table
doing some of that work. Two differently-built pipelines landing in the same
place is the reassuring outcome.

The series-detection heuristic is the weakest link: two separate BO3s between
the same teams on the same day would be merged into one. That is rare, and it
affects the series-lead term only.

---

## 11. Reproducing known results

Worth running once so you trust the setup.

```bash
# ~64.2% overall, LCK ~69.8%, LCS ~57.8%
node run.mjs data/2023.csv data/2024.csv data/2025.csv

# the game-1 pocket question: expect halving slightly ahead, well inside noise
node run.mjs --ab presets/halved-game1-pocket.json data/2023.csv data/2024.csv data/2025.csv

# pocket point: expect flat to 1.5, then a clear decline
node sweep.mjs --key pocketPoint --from 0.5 --to 3 --step 0.5 data/*.csv

# how much of the accuracy is cross-region team strength rather than draft
node run.mjs --ab presets/no-rank-edge.json data/*.csv
```

---

## 12. Troubleshooting

**"CSV is missing the *x* column"** — that is a trimmed export. You need the
full Oracle's Elixir file.

**Very few games loaded** — the lab drops games without ten complete player
rows, two team rows, a parseable date, and exactly one winner. Some files are
genuinely pre-filtered to a handful of leagues; check the league pills shown
after loading.

**Accuracy near 50%** — check the blue-side base rate line. If you filtered the
scope down to a few hundred games you are mostly looking at noise.

**Accuracy above 75%** — you have leaked the future. Re-read §8.

**Browser tab freezes** — it shouldn't; the backtest yields every 256 games.
If you loaded a very large set, use `run.mjs` instead.

**Changes to the HTML not showing up** — hard-reload (Ctrl/Cmd-Shift-R). If you
edited the core and `run.mjs` still behaves the old way, check you did not
accidentally break the `<script id="lab-core">` open or close tag; the runner
finds the block by that exact string.
