#!/usr/bin/env node
/**
 * Sweep one setting across a range and print the curve.
 *
 * A single backtest tells you whether a value is good. A sweep tells you
 * whether the value *matters* — a flat curve means the term is doing
 * nothing and the one number you measured was luck.
 *
 *   node sweep.mjs --key pocketPoint --from 0.5 --to 3 --step 0.25 data/*.csv
 *   node sweep.mjs --key probScale --from 1.5 --to 5 --step 0.5 data/*.csv
 *   node sweep.mjs --key rankCap --from 0 --to 3 --step 0.25 --settings presets/x.json data/*.csv
 *
 * Values are compared against the FIRST point in the sweep on the
 * head-to-head games, so the "vs first" column is the honest read.
 */
import { readFileSync } from 'node:fs';
import { loadCore, coerce } from './run.mjs';

const argv = process.argv.slice(2);
const arg = (name, def) => {
  const i = argv.indexOf('--' + name);
  return i === -1 ? def : argv[i + 1];
};
const files = argv.filter((a, i) => !a.startsWith('--') && !String(argv[i - 1] ?? '').startsWith('--'));

const key = arg('key');
if (!key || !files.length) {
  console.log('usage: node sweep.mjs --key <setting> --from <n> --to <n> --step <n> [--settings f.json] <csv...>');
  process.exit(1);
}
const from = Number(arg('from', 0));
const to = Number(arg('to', 1));
const step = Number(arg('step', 0.25));

const core = loadCore();
if (!(key in core.DEFAULT_SETTINGS)) {
  console.error(`"${key}" is not a setting. Known keys:\n  ` +
    Object.keys(core.DEFAULT_SETTINGS).join(', '));
  process.exit(1);
}

let games = [];
for (const f of files) {
  process.stderr.write(`reading ${f} ... `);
  const part = core.readCsv(readFileSync(f, 'utf8'));
  process.stderr.write(`${part.length} games\n`);
  games = games.concat(part);
}
games.sort((a, b) => a.ts - b.ts || (a.id < b.id ? -1 : 1));
core.buildSeries(games);

const base = coerce(core, arg('settings') ? JSON.parse(readFileSync(arg('settings'), 'utf8')) : {});

console.log(`\nsweeping ${key} from ${from} to ${to} step ${step} over ${games.length} games\n`);
console.log(`  ${key.padEnd(12)}  graded  accuracy      W-L      Brier    matched   vs first`);

let first = null;
for (let v = from; v <= to + 1e-9; v += step) {
  const value = Number(v.toFixed(6));
  const res = core.backtest(games, { ...base, [key]: value }, null);
  const st = core.stats(res.rows, res.settings.probScale);
  const mb = core.matchedBrier(res.rows);

  let cmp = '';
  if (first === null) first = res;
  else {
    const m = new Map(first.rows.map((r) => [r.id, r]));
    let flips = 0, win = 0, delta = 0;
    for (const r of res.rows) {
      const o = m.get(r.id);
      if (!o) continue;
      const a = Math.abs(r.m) < 1e-9 ? null : r.m > 0;
      const b = Math.abs(o.m) < 1e-9 ? null : o.m > 0;
      if (a === b) continue;
      flips++;
      if (a !== null && a === r.w) { win++; delta++; } else delta--;
    }
    cmp = flips
      ? `${delta >= 0 ? '+' : ''}${delta} of ${flips} flips (p=${core.binomP(flips, win).toFixed(2)})`
      : 'identical';
  }

  console.log(`  ${String(value).padEnd(12)}  ${String(st.n).padStart(6)}  ` +
    `${st.acc.toFixed(2).padStart(6)}%  ${String(st.right).padStart(5)}-${String(st.wrong).padEnd(5)}  ` +
    `${st.brier.toFixed(4)}   ${mb.brier.toFixed(4)}   ${cmp}`);
}

console.log(`
Read the curve, not the peak. If accuracy wanders inside a band of a few
games with no shape to it, the setting is not doing anything and the best
value in the list is noise. A real term shows a smooth hill with a top.`);
