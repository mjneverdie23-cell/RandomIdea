DraftCall Predictor Lab
=======================

A sandbox copy of the DraftCall prediction model where every constant is a
knob you can turn, and you can backtest the result against real games
yourself.

This is a mod. It does not touch the live app, and nothing you change here
changes the predictor on the site.


START HERE
----------

1. Get Oracle's Elixir match data CSVs from oracleselixir.com (Downloads).
   You need the FULL exports (160-odd columns), not the trimmed ones.

2. Open predictor-lab.html in a browser. Just double-click it — there is
   nothing to install and it works offline.

3. Drop the CSVs on the box at the top left, change some settings, and
   press "Run backtest".

4. "A/B vs defaults" is usually the button you actually want: it runs your
   settings against the shipped ones over the same games and tells you
   whether the difference is bigger than noise.


FROM THE COMMAND LINE
---------------------

Better for long runs and the only sane way to sweep. Needs Node 18+, no
npm install.

    node run.mjs data/*.csv
    node run.mjs --set pocketPoint=2.5 --set leagues=LCK data/*.csv
    node run.mjs --ab presets/halved-game1-pocket.json data/*.csv
    node sweep.mjs --key pocketPoint --from 0.5 --to 3 --step 0.25 data/*.csv


THEN READ THE NOTEBOOK
----------------------

NOTEBOOK.md covers what every setting does, how to read the output without
fooling yourself, how to add your own settings and scoring terms, and the
one rule that must never be broken (the model must never see the game it is
predicting). It also lists what has already been measured, so you do not
spend an evening rediscovering a dead end.
