#!/usr/bin/env node
/**
 * Headless runner for the Predictor Lab.
 *
 * It extracts the core out of predictor-lab.html and runs it under Node, so
 * the browser and the command line are always running byte-identical model
 * code. Use this for anything long: full-season backtests, sweeps, or A/B
 * runs you want to leave going.
 *
 *   node run.mjs data/*.csv
 *   node run.mjs --settings presets/halved-pocket.json data/*.csv
 *   node run.mjs --set pocketPoint=2.5 --set leagues=LCK data/*.csv
 *   node run.mjs --ab presets/halved-pocket.json data/*.csv
 *   node run.mjs --json out.json data/*.csv
 */
import { readFileSync, writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';

const HERE = dirname(fileURLToPath(import.meta.url));

/** Pull the <script id="lab-core"> block out of the HTML and evaluate it. */
export function loadCore(htmlPath = resolve(HERE, 'predictor-lab.html')) {
  const html = readFileSync(htmlPath, 'utf8');
  const m = html.match(/<script id="lab-core">([\s\S]*?)<\/script>/);
  if (!m) throw new Error('Could not find the <script id="lab-core"> block in ' + htmlPath);
  const module = { exports: {} };
  new Function('module', m[1])(module);
  return module.exports;
}

/* ------------------------------------------------------------------ */

function parseArgs(argv) {
  const out = { files: [], set: {}, settings: null, ab: null, json: null, quiet: false };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--settings') out.settings = argv[++i];
    else if (a === '--ab') out.ab = argv[++i];
    else if (a === '--json') out.json = argv[++i];
    else if (a === '--quiet') out.quiet = true;
    else if (a === '--set') {
      const [k, ...rest] = argv[++i].split('=');
      out.set[k] = rest.join('=');
    } else if (a.startsWith('-')) throw new Error('Unknown flag ' + a);
    else out.files.push(a);
  }
  return out;
}

/** Settings files and --set values arrive as strings; put them back in type. */
export function coerce(core, raw) {
  const types = new Map();
  for (const g of core.SETTINGS_SCHEMA) for (const it of g.items) types.set(it.key, it);
  const out = {};
  for (const [k, v] of Object.entries(raw)) {
    const it = types.get(k);
    if (!it) { out[k] = v; continue; }
    if (it.type === 'bool') out[k] = v === true || v === 'true' || v === '1';
    else if (it.type === 'text' || it.type === 'select') out[k] = String(v);
    else out[k] = Number(v);
  }
  return out;
}

const pad = (v, n) => String(v).padStart(n);
const pct = (v) => v.toFixed(2) + '%';

function report(core, res, label) {
  const { rows } = res;
  const scale = res.settings.probScale;
  const all = core.stats(rows, scale);
  const mb = core.matchedBrier(rows);

  console.log(`\n=== ${label} ===`);
  console.log(`  graded ${all.n} games   history pool ${res.historyGames}`);
  console.log(`  skipped: out of scope ${res.skipped.scope}, cold start ${res.skipped.history}, bo1 ${res.skipped.bo1}`);
  console.log(`  ACCURACY ${pct(all.acc)}   ${all.right}-${all.wrong}${all.level ? ` (${all.level} level)` : ''}` +
    `   blue base ${pct(all.blueRate)}`);
  console.log(`  Brier ${all.brier.toFixed(4)}   matched ${mb.brier.toFixed(4)} @ scale ${mb.scale.toFixed(2)}`);

  const table = (title, groups, min) => {
    const shown = groups.filter(([, l]) => l.length >= min);
    if (!shown.length) return;
    console.log(`\n  ${title}`);
    for (const [k, l] of shown) {
      const st = core.stats(l, scale);
      console.log(`    ${String(k).padEnd(14)} n=${pad(st.n, 5)}   ${pad(pct(st.acc), 7)}   ` +
        `${pad(st.right, 4)}-${pad(st.wrong, 4)}   brier ${st.brier.toFixed(4)}`);
    }
  };
  table('by year', core.groupBy(rows, (r) => r.y).sort((a, b) => (a[0] < b[0] ? -1 : 1)), 1);
  table('by league', core.groupBy(rows, (r) => r.lg), 30);
  table('by game number', core.groupBy(rows, (r) => 'game ' + r.gn).sort((a, b) => (a[0] < b[0] ? -1 : 1)), 30);
}

function compare(core, a, b, la, lb) {
  // Align on game id so scope differences cannot silently mismatch the rows.
  const mb = new Map(b.rows.map((r) => [r.id, r]));
  const pairs = a.rows.filter((r) => mb.has(r.id)).map((r) => [r, mb.get(r.id)]);
  console.log(`\n=== ${la}  vs  ${lb} ===`);
  console.log(`  ${pairs.length} games graded by both`);

  const sa = core.stats(pairs.map((p) => p[0]), a.settings.probScale);
  const sb = core.stats(pairs.map((p) => p[1]), b.settings.probScale);
  console.log(`  ${la.padEnd(20)} ${pct(sa.acc)}   ${sa.right}-${sa.wrong}   brier ${sa.brier.toFixed(4)}`);
  console.log(`  ${lb.padEnd(20)} ${pct(sb.acc)}   ${sb.right}-${sb.wrong}   brier ${sb.brier.toFixed(4)}`);
  const d = sa.right - sb.right;
  console.log(`  -> ${la} ${d >= 0 ? '+' : ''}${d} games`);

  // Only the games where the two actually disagree carry information.
  let flips = 0, aWin = 0;
  for (const [x, y] of pairs) {
    const px = Math.abs(x.m) < 1e-9 ? null : x.m > 0;
    const py = Math.abs(y.m) < 1e-9 ? null : y.m > 0;
    if (px === py) continue;
    flips++;
    if (px !== null && px === x.w) aWin++;
  }
  console.log(`  disagreements: ${flips}   ${la} right ${aWin}   ${lb} right ${flips - aWin}` +
    (flips ? `   two-sided p = ${core.binomP(flips, aWin).toFixed(3)}` : ''));
  if (flips < 30) console.log('  (too few disagreements to separate these settings)');
}

async function main() {
  const args = parseArgs(process.argv.slice(2));
  if (!args.files.length) {
    console.log('usage: node run.mjs [--settings f.json] [--ab other.json] [--set k=v] [--json out.json] <csv...>');
    process.exit(1);
  }
  const core = loadCore();

  let games = [];
  for (const f of args.files) {
    process.stderr.write(`reading ${f} ... `);
    const part = core.readCsv(readFileSync(f, 'utf8'));
    process.stderr.write(`${part.length} games\n`);
    games = games.concat(part);
  }
  games.sort((a, b) => a.ts - b.ts || (a.id < b.id ? -1 : 1));
  core.buildSeries(games);
  console.log(`loaded ${games.length} games, ${games[0]?.date?.slice(0, 10)} to ${games.at(-1)?.date?.slice(0, 10)}`);

  const fileSettings = args.settings ? JSON.parse(readFileSync(args.settings, 'utf8')) : {};
  const settings = coerce(core, { ...fileSettings, ...args.set });

  const res = backtestTimed(core, games, settings, 'yours');
  report(core, res, args.settings ? args.settings : 'your settings');

  if (args.ab) {
    const other = coerce(core, JSON.parse(readFileSync(args.ab, 'utf8')));
    const res2 = backtestTimed(core, games, other, 'B');
    report(core, res2, args.ab);
    compare(core, res, res2, 'yours', args.ab);
  }
  if (args.json) {
    writeFileSync(args.json, JSON.stringify(res));
    console.log(`\nwrote ${args.json}`);
  }
}

function backtestTimed(core, games, settings, label) {
  const t0 = Date.now();
  const res = core.backtest(games, settings, null);
  process.stderr.write(`backtest (${label}) took ${((Date.now() - t0) / 1000).toFixed(1)}s\n`);
  return res;
}

if (process.argv[1] && process.argv[1].endsWith('run.mjs')) main();
